package com.textview.app;

/**
 * Created by cretin on 15/12/30.
 */
public class AppConstants {
    /**
     * 指定在MyRelativeLayout中滑动的方向
     */
    public static final int MOVE_LEFT = 6;
    public static final int MOVE_RIGHT = 7;
}
