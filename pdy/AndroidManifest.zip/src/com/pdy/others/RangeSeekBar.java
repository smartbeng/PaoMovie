package com.pdy.others;

import java.math.BigDecimal;

import com.pdy.mobile.StaticMethod;
import com.pdy.mobile.R;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.FontMetrics;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.ImageView;

/**
 * Widget that lets users select a minimum and maximum value on a given
 * numerical range. The range value types can be one of Long, Double, Integer,
 * Float, Short, Byte or BigDecimal.<br />
 * <br />
 * Improved {@link MotionEvent} handling for smoother use, anti-aliased painting
 * for improved aesthetics.
 * 
 * @author Stephan Tittel (stephan.tittel@kom.tu-darmstadt.de)
 * @author Peter Sinnott (psinnott@gmail.com)
 * @author Thomas Barrasso (tbarrasso@sevenplusandroid.org)
 * @author Yao (chuan_27049@126.com)
 * 
 * @param <T>
 *            The Number type of the range values. One of Long, Double, Integer,
 *            Float, Short, Byte or BigDecimal.
 */
public class RangeSeekBar<T extends Number> extends ImageView {
	private static final String TAG = RangeSeekBar.class.getSimpleName();
	private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
	private final Paint thumbValuePaint = getThumbValuePaint();
	private final Bitmap thumbImage = BitmapFactory.decodeResource(getResources(), R.drawable.jiantou_right);
	private final Bitmap thumbPressedImage = BitmapFactory.decodeResource(getResources(), R.drawable.jiantou_left);
	private final float thumbWidth = thumbImage.getWidth();
	private final float thumbHalfWidth = 0.5f * thumbWidth;
	private final float thumbHalfHeight = 0.5f * thumbImage.getHeight();
	private final float padding = thumbHalfWidth;
	private final T absoluteMinValue, absoluteMaxValue;
	private final NumberType numberType;
	private final double absoluteMinValuePrim, absoluteMaxValuePrim;
	private double normalizedMinValue = 0d;
	private double normalizedMaxValue = 1d;// normalized锟斤拷锟斤拷窕�碉拷--锟斤拷锟斤拷锟斤拷占锟杰筹拷锟饺的憋拷锟斤拷值锟斤拷锟斤拷围锟斤拷0-1
	private Thumb pressedThumb = null;
	private boolean notifyWhileDragging = false;
	private OnRangeSeekBarChangeListener<T> listener;
	public int start;

	/**
	 * Default color of a {@link RangeSeekBar}, #FF33B5E5. This is also known as
	 * "Ice Cream Sandwich" blue.
	 */
	public static final int DEFAULT_COLOR = Color.argb(0xFF, 0x33, 0xB5, 0xE5);

	/**
	 * An invalid pointer id.
	 */
	public static final int INVALID_POINTER_ID = 255;

	// Localized constants from MotionEvent for compatibility
	// with API < 8 "Froyo".
	public static final int ACTION_POINTER_UP = 0x6, ACTION_POINTER_INDEX_MASK = 0x0000ff00,
			ACTION_POINTER_INDEX_SHIFT = 8;

	private float mDownMotionX;// 锟斤拷录touchEvent锟斤拷锟斤拷时锟斤拷X锟斤拷锟斤拷
	private int mActivePointerId = INVALID_POINTER_ID;

	/**
	 * On touch, this offset plus the scaled value from the position of the
	 * touch will form the progress value. Usually 0.
	 */
	float mTouchProgressOffset;

	private int mScaledTouchSlop;
	private boolean mIsDragging;

	/**
	 * Creates a new RangeSeekBar.
	 * 
	 * @param absoluteMinValue
	 *            The minimum value of the selectable range.
	 * @param absoluteMaxValue
	 *            The maximum value of the selectable range.
	 * @param context
	 * @throws IllegalArgumentException
	 *             Will be thrown if min/max value type is not one of Long,
	 *             Double, Integer, Float, Short, Byte or BigDecimal.
	 */
	public RangeSeekBar(T absoluteMinValue, T absoluteMaxValue, Context context) throws IllegalArgumentException {
		super(context);

		this.absoluteMinValue = absoluteMinValue;
		this.absoluteMaxValue = absoluteMaxValue;
		absoluteMinValuePrim = absoluteMinValue.doubleValue();// 锟斤拷转锟斤拷为double锟斤拷锟酵碉拷值
		absoluteMaxValuePrim = absoluteMaxValue.doubleValue();
		numberType = NumberType.fromNumber(absoluteMinValue);// 锟矫碉拷锟斤拷锟斤拷锟斤拷锟街碉拷枚锟斤拷锟斤拷锟斤拷

		// make RangeSeekBar focusable. This solves focus handling issues in
		// case EditText widgets are being used along with the RangeSeekBar
		// within ScollViews.
		setFocusable(true);
		setFocusableInTouchMode(true);
		init();
	}

	private final void init() {
		// 锟斤拷锟斤拷为锟角达拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷叹锟斤拷锟�
		mScaledTouchSlop = ViewConfiguration.get(getContext()).getScaledTouchSlop();
	}

	/**
	 * 锟斤拷锟解部activity锟斤拷锟矫ｏ拷锟斤拷锟斤拷锟角讹拷锟斤拷锟较讹拷锟斤拷时锟斤拷锟接�log锟斤拷息锟斤拷默锟斤拷锟斤拷false锟斤拷锟斤拷印
	 */
	public boolean isNotifyWhileDragging() {
		return notifyWhileDragging;
	}

	/**
	 * Should the widget notify the listener callback while the user is still
	 * dragging a thumb? Default is false.
	 * 
	 * @param flag
	 */
	public void setNotifyWhileDragging(boolean flag) {
		this.notifyWhileDragging = flag;
	}

	/**
	 * Returns the absolute minimum value of the range that has been set at
	 * construction time.
	 * 
	 * @return The absolute minimum value of the range.
	 */
	public T getAbsoluteMinValue() {
		return absoluteMinValue;
	}

	/**
	 * Returns the absolute maximum value of the range that has been set at
	 * construction time.
	 * 
	 * @return The absolute maximum value of the range.
	 */
	public T getAbsoluteMaxValue() {
		return absoluteMaxValue;
	}

	/**
	 * Returns the currently selected min value.
	 * 
	 * @return The currently selected min value.
	 */
	public T getSelectedMinValue() {
		return normalizedToValue(normalizedMinValue);
	}

	/**
	 * Sets the currently selected minimum value. The widget will be invalidated
	 * and redrawn.
	 * 
	 * @param value
	 *            The Number value to set the minimum value to. Will be clamped
	 *            to given absolute minimum/maximum range.
	 */
	public void setSelectedMinValue(T value) {
		// in case absoluteMinValue == absoluteMaxValue, avoid division by zero
		// when normalizing.
		if (0 == (absoluteMaxValuePrim - absoluteMinValuePrim)) {
			// activity锟斤拷锟矫碉拷锟斤拷锟街碉拷锟斤拷锟叫≈碉拷锟斤拷
			setNormalizedMinValue(0d);
		} else {
			setNormalizedMinValue(valueToNormalized(value));
		}
	}

	/**
	 * Returns the currently selected max value.
	 * 
	 * @return The currently selected max value.
	 */
	public T getSelectedMaxValue() {
		return normalizedToValue(normalizedMaxValue);
	}

	/**
	 * Sets the currently selected maximum value. The widget will be invalidated
	 * and redrawn.
	 * 
	 * @param value
	 *            The Number value to set the maximum value to. Will be clamped
	 *            to given absolute minimum/maximum range.
	 */
	public void setSelectedMaxValue(T value) {
		// in case absoluteMinValue == absoluteMaxValue, avoid division by zero
		// when normalizing.
		if (0 == (absoluteMaxValuePrim - absoluteMinValuePrim)) {
			setNormalizedMaxValue(1d);
		} else {
			setNormalizedMaxValue(valueToNormalized(value));
		}
	}

	/**
	 * Registers given listener callback to notify about changed selected
	 * values.
	 * 
	 * @param listener
	 *            The listener to notify about changed selected values.
	 */
	public void setOnRangeSeekBarChangeListener(OnRangeSeekBarChangeListener<T> listener) {
		this.listener = listener;
	}

	/**
	 * Handles thumb selection and movement. Notifies listener callback on
	 * certain events.
	 * 
	 * 
	 * ACTION_MASK锟斤拷Android锟斤拷锟斤拷应锟斤拷锟节讹拷愦ワ拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷系锟斤拷锟剿硷拷锟斤拷锟角讹拷锟斤拷锟斤拷锟斤拷锟斤拷锟剿硷拷伞锟�
	 * 锟斤拷onTouchEvent(MotionEvent event)锟叫ｏ拷使锟斤拷switch
	 * (event.getAction())锟斤拷锟皆达拷锟斤拷ACTION_DOWN锟斤拷ACTION_UP锟铰硷拷锟斤拷使锟斤拷switch
	 * (event.getAction() & MotionEvent.ACTION_MASK)
	 * 锟酵匡拷锟皆达拷锟斤拷锟斤拷锟姐触锟斤拷锟斤拷ACTION_POINTER_DOWN锟斤拷ACTION_POINTER_UP锟铰硷拷锟斤拷
	 */
	@Override
	public boolean onTouchEvent(MotionEvent event) {

		if (!isEnabled())
			return false;

		int pointerIndex;// 锟斤拷录锟斤拷锟斤拷锟斤拷index

		final int action = event.getAction();
		switch (action & MotionEvent.ACTION_MASK) {

		case MotionEvent.ACTION_DOWN:
			// Remember where the motion event started
			// event.getPointerCount() -
			// 1锟矫碉拷锟斤拷锟揭伙拷锟斤拷锟斤拷锟斤拷幕锟侥点，锟斤拷锟斤拷牡锟�id锟斤拷0锟斤拷event.getPointerCount()
			// - 1
			mActivePointerId = event.getPointerId(event.getPointerCount() - 1);
			pointerIndex = event.findPointerIndex(mActivePointerId);
			mDownMotionX = event.getX(pointerIndex);// 锟矫碉拷pointerIndex锟斤拷锟斤拷锟斤拷X锟斤拷锟斤拷

			pressedThumb = evalPressedThumb(mDownMotionX);// 锟叫讹拷touch锟斤拷锟斤拷锟斤拷锟斤拷锟街�thumb锟斤拷锟斤拷锟斤拷小值thumb

			// Only handle thumb presses.
			if (pressedThumb == null)
				return super.onTouchEvent(event);

			setPressed(true);// 锟斤拷锟矫该控硷拷锟斤拷锟斤拷锟斤拷锟斤拷
			invalidate();// 通知执锟斤拷onDraw锟斤拷锟斤拷
			onStartTrackingTouch();// 锟斤拷mIsDragging为true锟斤拷锟斤拷始追锟斤拷touch锟铰硷拷
			trackTouchEvent(event);
			attemptClaimDrag();

			break;
		case MotionEvent.ACTION_MOVE:
			if (pressedThumb != null) {

				if (mIsDragging) {
					trackTouchEvent(event);
				} else {
					// Scroll to follow the motion event
					pointerIndex = event.findPointerIndex(mActivePointerId);
					final float x = event.getX(pointerIndex);// 锟斤拷指锟节控硷拷锟较碉拷锟�X锟斤拷锟斤拷
					// 锟斤拷指没锟叫碉拷锟斤拷锟斤拷锟斤拷锟叫≈碉拷希锟斤拷锟斤拷锟斤拷诳丶锟斤拷锟斤拷谢锟斤拷锟斤拷录锟�
					if (Math.abs(x - mDownMotionX) > mScaledTouchSlop) {
						setPressed(true);
						Log.e(TAG, "没锟斤拷锟斤拷住锟斤拷锟斤拷锟叫≈�");// 一直锟斤拷锟斤拷执锟叫ｏ拷
						invalidate();
						onStartTrackingTouch();
						trackTouchEvent(event);
						attemptClaimDrag();
					}
				}

				if (notifyWhileDragging && listener != null) {
					listener.onRangeSeekBarValuesChanged(this, getSelectedMinValue(), getSelectedMaxValue());
				}
			}
			break;
		case MotionEvent.ACTION_UP:
			if (mIsDragging) {
				trackTouchEvent(event);
				onStopTrackingTouch();
				setPressed(false);
			} else {
				// Touch up when we never crossed the touch slop threshold
				// should be interpreted as a tap-seek to that location.
				onStartTrackingTouch();
				trackTouchEvent(event);
				onStopTrackingTouch();
			}

			pressedThumb = null;// 锟斤拷指抬锟斤拷锟斤拷锟矫憋拷touch锟斤拷锟斤拷thumb为锟斤拷
			invalidate();
			if (listener != null) {
				listener.onRangeSeekBarValuesChanged(this, getSelectedMinValue(), getSelectedMaxValue());
			}
			break;
		case MotionEvent.ACTION_POINTER_DOWN: {
			final int index = event.getPointerCount() - 1;
			// final int index = ev.getActionIndex();
			mDownMotionX = event.getX(index);
			mActivePointerId = event.getPointerId(index);
			invalidate();
			break;
		}
		case MotionEvent.ACTION_POINTER_UP:
			onSecondaryPointerUp(event);
			invalidate();
			break;
		case MotionEvent.ACTION_CANCEL:
			if (mIsDragging) {
				onStopTrackingTouch();
				setPressed(false);
			}
			invalidate(); // see above explanation
			break;
		}
		return true;
	}

	private final void onSecondaryPointerUp(MotionEvent ev) {
		final int pointerIndex = (ev.getAction() & ACTION_POINTER_INDEX_MASK) >> ACTION_POINTER_INDEX_SHIFT;

		final int pointerId = ev.getPointerId(pointerIndex);
		if (pointerId == mActivePointerId) {
			// This was our active pointer going up. Choose
			// a new active pointer and adjust accordingly.
			// TODO: Make this decision more intelligent.
			final int newPointerIndex = pointerIndex == 0 ? 1 : 0;
			mDownMotionX = ev.getX(newPointerIndex);
			mActivePointerId = ev.getPointerId(newPointerIndex);
		}
	}

	/**
	 * 一直追锟斤拷touch锟铰硷拷锟斤拷刷锟斤拷view
	 * 
	 * @param event
	 */
	private final void trackTouchEvent(MotionEvent event) {
		final int pointerIndex = event.findPointerIndex(mActivePointerId);// 锟矫碉拷锟斤拷锟铰碉拷锟�index
		final float x = event.getX(pointerIndex);// 锟矫碉拷锟斤拷前pointerIndex锟斤拷锟斤拷幕锟较碉拷x锟斤拷锟斤拷

		if (Thumb.MIN.equals(pressedThumb)) {
			// screenToNormalized(x)-->锟矫碉拷锟斤拷窕�碉拷0-1锟斤拷值
			setNormalizedMinValue(screenToNormalized(x));
		} else if (Thumb.MAX.equals(pressedThumb)) {
			setNormalizedMaxValue(screenToNormalized(x));
		}
	}

	/**
	 * Tries to claim the user's drag motion, and requests disallowing any
	 * ancestors from stealing events in the drag.
	 * 
	 * 锟斤拷图锟斤拷锟竭革拷view锟斤拷要锟斤拷锟斤拷锟接控硷拷锟斤拷drag
	 */
	private void attemptClaimDrag() {
		if (getParent() != null) {
			getParent().requestDisallowInterceptTouchEvent(true);
		}
	}

	/**
	 * This is called when the user has started touching this widget.
	 */
	void onStartTrackingTouch() {
		mIsDragging = true;
	}

	/**
	 * This is called when the user either releases his touch or the touch is
	 * canceled.
	 */
	void onStopTrackingTouch() {
		mIsDragging = false;
	}

	/**
	 * Ensures correct size of the widget.
	 */
	@Override
	protected synchronized void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		int width = 200;
		if (MeasureSpec.UNSPECIFIED != MeasureSpec.getMode(widthMeasureSpec)) {
			width = MeasureSpec.getSize(widthMeasureSpec);
		}
		int height = thumbImage.getHeight();
		if (MeasureSpec.UNSPECIFIED != MeasureSpec.getMode(heightMeasureSpec)) {
			// 锟竭讹拷为锟斤拷锟斤拷锟斤拷锟竭讹拷+锟斤拷锟街伙拷锟绞高讹拷
			height = Math.min(height, MeasureSpec.getSize(heightMeasureSpec))
					+ (int) getFontHeight(thumbValuePaint) * 2;
		}
		setMeasuredDimension(width, height);
	}

	/**
	 * Draws the widget on the given canvas.
	 */
	@Override
	protected synchronized void onDraw(Canvas canvas) {
		super.onDraw(canvas);

		Bitmap l_bg = BitmapFactory.decodeResource(getResources(), R.drawable.transparent);
		Bitmap m_bg = BitmapFactory.decodeResource(getResources(), R.drawable.transparent);
		Bitmap r_bg = BitmapFactory.decodeResource(getResources(), R.drawable.transparent);
		Bitmap m_progress = BitmapFactory.decodeResource(getResources(), R.drawable.transparent);

		canvas.drawBitmap(l_bg, padding - thumbHalfWidth, 0.5f * (getHeight() - l_bg.getHeight()), paint);

		float bg_middle_left = padding - thumbHalfWidth + l_bg.getWidth();// 锟斤拷要平锟教碉拷锟叫间背锟斤拷锟侥匡拷始锟斤拷锟斤拷
		float bg_middle_right = getWidth() - padding + thumbHalfWidth - l_bg.getWidth();// 锟斤拷要平锟教碉拷锟叫间背锟斤拷锟侥匡拷始锟斤拷锟斤拷

		float scale = (bg_middle_right - bg_middle_left) / m_progress.getWidth();// 锟较诧拷锟斤拷锟斤拷锟叫≈碉拷锟斤拷锟斤拷锟斤拷m_progress锟斤拷锟斤拷
		Matrix mx = new Matrix();
		mx.postScale(scale, 1f);
		Bitmap m_bg_new = Bitmap.createBitmap(m_bg, 0, 0, m_progress.getWidth(), m_progress.getHeight(), mx, true);
		canvas.drawBitmap(m_bg_new, bg_middle_left, 0.5f * (getHeight() - m_bg.getHeight()), paint);

		canvas.drawBitmap(r_bg, bg_middle_right, 0.5f * (getHeight() - r_bg.getHeight()), paint);

		float rangeL = normalizedToScreen(normalizedMinValue);
		float rangeR = normalizedToScreen(normalizedMaxValue);
		// float length = rangeR - rangeL;
		float pro_scale = (rangeR - rangeL) / m_progress.getWidth();// 锟较诧拷锟斤拷锟斤拷锟叫≈碉拷锟斤拷锟斤拷锟斤拷m_progress锟斤拷锟斤拷
		if (pro_scale > 0) {

			Matrix pro_mx = new Matrix();
			pro_mx.postScale(pro_scale, 1f);
			try {

				Bitmap m_progress_new = Bitmap.createBitmap(m_progress, 0, 0, m_progress.getWidth(),
						m_progress.getHeight(), pro_mx, true);

				canvas.drawBitmap(m_progress_new, rangeL, 0.5f * (getHeight() - m_progress.getHeight()), paint);
			} catch (Exception e) {
				// 锟斤拷pro_scale锟角筹拷小锟斤拷锟斤拷锟斤拷width=12锟斤拷Height=48锟斤拷pro_scale=0.01979065时锟斤拷
				// 锟斤拷甙锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷值为0.237锟斤拷0.949锟斤拷系统强转为int锟酵猴拷锟酵憋拷锟�0锟剿★拷锟酵筹拷锟街非凤拷锟斤拷锟斤拷锟届常
				Log.e(TAG, "IllegalArgumentException--width=" + m_progress.getWidth() + "Height="
						+ m_progress.getHeight() + "pro_scale=" + pro_scale, e);

			}

		}

		// 锟斤拷锟�minThumb锟侥讹拷应锟斤拷值
		drawThumbMinValue(normalizedToScreen(normalizedMinValue),
				StaticMethod.secToTime(numberType.toNumber(start + getSelectedMinValue().intValue()).toString()),
				canvas);

		// 锟斤拷锟�maxThumb锟侥讹拷应锟斤拷值
		drawThumbMaxValue(normalizedToScreen(normalizedMaxValue),
				StaticMethod.secToTime(numberType.toNumber(start + getSelectedMaxValue().intValue()).toString()),
				canvas);

		// draw minimum thumb
		drawThumb(normalizedToScreen(normalizedMinValue), thumbImage, canvas);

		// draw maximum thumb
		drawThumb(normalizedToScreen(normalizedMaxValue), thumbPressedImage, canvas);

	}

	/**
	 * Overridden to save instance state when device orientation changes. This
	 * method is called automatically if you assign an id to the RangeSeekBar
	 * widget using the {@link #setId(int)} method. Other members of this class
	 * than the normalized min and max values don't need to be saved.
	 */
	@Override
	protected Parcelable onSaveInstanceState() {
		final Bundle bundle = new Bundle();
		bundle.putParcelable("SUPER", super.onSaveInstanceState());
		bundle.putDouble("MIN", normalizedMinValue);
		bundle.putDouble("MAX", normalizedMaxValue);
		return bundle;
	}

	/**
	 * Overridden to restore instance state when device orientation changes.
	 * This method is called automatically if you assign an id to the
	 * RangeSeekBar widget using the {@link #setId(int)} method.
	 */
	@Override
	protected void onRestoreInstanceState(Parcelable parcel) {
		final Bundle bundle = (Bundle) parcel;
		super.onRestoreInstanceState(bundle.getParcelable("SUPER"));
		normalizedMinValue = bundle.getDouble("MIN");
		normalizedMaxValue = bundle.getDouble("MAX");
	}

	/**
	 * Draws the "normal" resp. "pressed" thumb image on specified x-coordinate.
	 * 
	 * @param screenCoord
	 *            The x-coordinate in screen space where to draw the image.
	 * @param pressed
	 *            Is the thumb currently in "pressed" state?
	 * @param canvas
	 *            The canvas to draw upon.
	 */
	private void drawThumb(float screenCoord, Bitmap bitmap, Canvas canvas) {
		canvas.drawBitmap(bitmap, screenCoord - thumbHalfWidth, (float) ((0.5f * getHeight()) - thumbHalfHeight),
				paint);
	}

	/**
	 * 锟斤拷thumb锟斤拷应锟斤拷锟斤拷小值
	 * 
	 * @param screenCoord
	 * @param text
	 * @param canvas
	 */
	private void drawThumbMinValue(float screenCoord, String text, Canvas canvas) {

		// 锟矫碉拷maxThumb锟斤拷left锟斤拷锟斤拷幕锟较的撅拷锟斤拷锟斤拷锟斤拷
		float maxThumbleft = normalizedToScreen(normalizedMaxValue) - thumbHalfWidth;

		// 锟斤拷锟斤拷锟街碉拷right锟斤拷锟斤拷
		float textRight = screenCoord - thumbHalfWidth + getFontlength(thumbValuePaint, text);

		if (textRight >= maxThumbleft) {
			// 锟斤拷锟斤拷锟街碉拷锟揭边界到锟斤拷锟斤拷maxThumb锟斤拷锟斤拷呓锟绞�
			if (pressedThumb == Thumb.MIN) {
				// touch锟斤拷为min
				canvas.drawText(text, maxThumbleft - getFontlength(thumbValuePaint, text),
						(float) ((0.5f * getHeight()) - thumbHalfHeight) - 3, thumbValuePaint);

			} else {

				canvas.drawText(text, textRight - getFontlength(thumbValuePaint, text),
						(float) ((0.5f * getHeight()) - thumbHalfHeight) - 3, thumbValuePaint);

			}

			Log.e(TAG, "textRight>=maxThumbleft***textRight=" + textRight + "maxThumbleft=" + maxThumbleft);
		} else {
			// 锟斤拷锟斤拷也锟斤拷thumb锟斤拷锟斤拷呓缁�锟斤拷
			canvas.drawText(text, screenCoord - thumbHalfWidth, (float) ((0.5f * getHeight()) - thumbHalfHeight) - 3,
					thumbValuePaint);

			Log.i(TAG, "textRight<maxThumbleft***textRight=" + textRight + "maxThumbleft=" + maxThumbleft);
		}

	}

	private void drawThumbMaxValue(float screenCoord, String text, Canvas canvas) {

		// 锟矫碉拷minThumb锟斤拷锟街碉拷right锟斤拷锟斤拷幕锟较的撅拷锟斤拷锟斤拷锟斤拷
		float minThumbValueRight = normalizedToScreen(normalizedMinValue) - thumbHalfWidth
				+ getFontlength(thumbValuePaint, StaticMethod.secToTime(getSelectedMaxValue().toString()));

		// 锟斤拷锟斤拷锟街碉拷right锟斤拷锟斤拷
		float textRight = screenCoord - thumbHalfWidth + getFontlength(thumbValuePaint, text);

		if (textRight >= getWidth()) {
			// 锟斤拷锟街碉拷right锟竭斤拷锟斤拷锟斤拷锏斤拷锟斤拷锟斤拷锟侥伙拷锟斤拷时
			canvas.drawText(text, getWidth() - getFontlength(thumbValuePaint, text),
					(float) ((0.5f * getHeight()) - thumbHalfHeight) - 3, thumbValuePaint);

		} else if ((screenCoord - thumbHalfWidth) <= minThumbValueRight) {
			// maxThumb锟斤拷锟斤拷left锟竭斤拷锏�minThumb锟斤拷锟斤拷right锟竭斤拷
			if (pressedThumb == Thumb.MAX) {

				canvas.drawText(text, minThumbValueRight, (float) ((0.5f * getHeight()) - thumbHalfHeight) - 3,
						thumbValuePaint);

			} else {

				canvas.drawText(text, screenCoord - thumbHalfWidth,
						(float) ((0.5f * getHeight()) - thumbHalfHeight) - 3, thumbValuePaint);

			}

		} else {

			canvas.drawText(text, screenCoord - thumbHalfWidth, (float) ((0.5f * getHeight()) - thumbHalfHeight) - 3,
					thumbValuePaint);
		}

	}

	/**
	 * 取锟斤拷thumb值锟斤拷paint
	 */
	private Paint getThumbValuePaint() {
		Paint p = new Paint();
		p.setColor(Color.RED);
		p.setAntiAlias(true);// 去锟斤拷锟斤拷锟�
		p.setFilterBitmap(true);// 锟斤拷位图锟斤拷锟斤拷锟剿诧拷锟斤拷锟斤拷
		p.setTextSize(35);

		return p;
	}

	/**
	 * @return 锟斤拷锟斤拷指锟斤拷锟绞猴拷指锟斤拷锟街凤拷锟斤拷锟侥筹拷锟斤拷
	 */
	private float getFontlength(Paint paint, String str) {
		return paint.measureText(str);
	}

	/**
	 * @return 锟斤拷锟斤拷指锟斤拷锟绞碉拷锟斤拷锟街高讹拷
	 */
	private float getFontHeight(Paint paint) {
		FontMetrics fm = paint.getFontMetrics();
		return fm.descent - fm.ascent;
	}

	/**
	 * Decides which (if any) thumb is touched by the given x-coordinate.
	 * 
	 * eval 锟斤拷n. 锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟�
	 * 
	 * @param touchX
	 *            The x-coordinate of a touch event in screen space.
	 * @return The pressed thumb or null if none has been
	 *         touched.//锟斤拷touch锟斤拷锟角空伙拷锟斤拷锟斤拷锟街碉拷锟斤拷锟叫≈�
	 */
	private Thumb evalPressedThumb(float touchX) {
		Thumb result = null;
		boolean minThumbPressed = isInThumbRange(touchX, normalizedMinValue);// 锟斤拷锟斤拷锟斤拷锟角凤拷锟斤拷锟斤拷小值图片锟斤拷围锟斤拷
		boolean maxThumbPressed = isInThumbRange(touchX, normalizedMaxValue);
		if (minThumbPressed && maxThumbPressed) {
			// if both thumbs are pressed (they lie on top of each other),
			// choose the one with more room to drag. this avoids "stalling" the
			// thumbs in a corner, not being able to drag them apart anymore.

			// 锟斤拷锟斤拷锟斤拷锟�thumbs锟截碉拷锟斤拷一锟斤拷锟睫凤拷锟叫讹拷锟较讹拷锟侥革拷锟斤拷锟斤拷锟斤拷锟铰达拷锟斤拷
			// 锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷幕锟揭侧，锟斤拷锟叫讹拷为touch锟斤拷锟斤拷锟斤拷小值thumb锟斤拷锟斤拷之锟叫讹拷为touch锟斤拷锟斤拷锟斤拷锟街�thumb
			result = (touchX / getWidth() > 0.5f) ? Thumb.MIN : Thumb.MAX;
		} else if (minThumbPressed) {
			result = Thumb.MIN;
		} else if (maxThumbPressed) {
			result = Thumb.MAX;
		}
		return result;
	}

	/**
	 * Decides if given x-coordinate in screen space needs to be interpreted as
	 * "within" the normalized thumb x-coordinate.
	 * 
	 * @param touchX
	 *            The x-coordinate in screen space to check.
	 * @param normalizedThumbValue
	 *            The normalized x-coordinate of the thumb to check.
	 * @return true if x-coordinate is in thumb range, false otherwise.
	 */
	private boolean isInThumbRange(float touchX, double normalizedThumbValue) {
		// 锟斤拷前锟斤拷锟斤拷锟斤拷X锟斤拷锟斤拷-锟斤拷小值图片锟斤拷锟侥碉拷锟斤拷锟斤拷幕锟斤拷X锟斤拷锟斤拷之锟斤拷<=锟斤拷小锟斤拷图片锟侥匡拷鹊锟揭伙拷锟�
		// 锟斤拷锟叫断达拷锟斤拷锟斤拷锟角凤拷锟斤拷锟斤拷锟斤拷小值图片锟斤拷锟斤拷为原锟姐，锟斤拷锟揭伙拷锟轿�锟诫径锟斤拷圆锟节★拷
		return Math.abs(touchX - normalizedToScreen(normalizedThumbValue)) <= thumbHalfWidth;
	}

	/**
	 * Sets normalized min value to value so that 0 <= value <= normalized max
	 * value <= 1. The View will get invalidated when calling this method.
	 * 
	 * @param value
	 *            The new normalized min value to set.
	 */
	public void setNormalizedMinValue(double value) {
		normalizedMinValue = Math.max(0d, Math.min(1d, Math.min(value, normalizedMaxValue)));
		invalidate();// 锟斤拷锟铰伙拷锟狡达拷view
	}

	/**
	 * Sets normalized max value to value so that 0 <= normalized min value <=
	 * value <= 1. The View will get invalidated when calling this method.
	 * 
	 * @param value
	 *            The new normalized max value to set.
	 */
	public void setNormalizedMaxValue(double value) {
		normalizedMaxValue = Math.max(0d, Math.min(1d, Math.max(value, normalizedMinValue)));
		invalidate();
	}

	/**
	 * Converts a normalized value to a Number object in the value space between
	 * absolute minimum and maximum.
	 * 
	 * @param normalized
	 *            锟斤拷锟斤拷值锟斤拷锟斤拷锟侥碉拷锟轿伙拷锟斤拷诟锟斤拷锟斤拷艹锟斤拷鹊牡锟轿伙拷帽锟斤拷锟斤拷锟斤拷牡锟斤拷锟斤拷锟斤拷屑洌�锟斤拷么锟斤拷锟侥憋拷锟斤拷值锟斤拷锟斤拷0.5
	 * @return 通锟斤拷锟斤拷锟斤拷值锟斤拷锟杰筹拷锟饺硷拷锟斤拷贸锟斤拷锟绞碉拷锟斤拷锟斤拷锟街�锟斤拷
	 */
	@SuppressWarnings("unchecked")
	private T normalizedToValue(double normalized) {
		return (T) numberType
				.toNumber(absoluteMinValuePrim + normalized * (absoluteMaxValuePrim - absoluteMinValuePrim));
	}

	/**
	 * Converts the given Number value to a normalized double.
	 * 
	 * @param value
	 *            The Number value to normalize.
	 * @return The normalized double.
	 */
	private double valueToNormalized(T value) {
		if (0 == absoluteMaxValuePrim - absoluteMinValuePrim) {
			// prevent division by zero, simply return 0.
			return 0d;
		}
		return (value.doubleValue() - absoluteMinValuePrim) / (absoluteMaxValuePrim - absoluteMinValuePrim);
	}

	/**
	 * Converts a normalized value into screen space.
	 * 
	 * @param normalizedCoord
	 *            The normalized value to convert.
	 * @return The converted value in screen
	 *         space.//图片锟斤拷锟侥碉拷锟斤拷锟斤拷幕锟较的撅拷锟斤拷锟斤拷锟斤拷值
	 */
	private float normalizedToScreen(double normalizedCoord) {
		// getWidth() - 2 * padding --> 锟斤拷锟斤拷View锟斤拷燃锟饺ワ拷锟斤拷锟�padding锟斤拷
		// 锟斤拷锟斤拷去一锟斤拷thumb锟侥匡拷锟�,锟斤拷锟斤拷锟斤拷thumb锟缴伙拷锟斤拷锟侥凤拷围锟斤拷锟斤拷

		// normalizedCoord * (getWidth() - 2 * padding)
		// 锟斤拷锟街碉拷氤わ拷鹊某杉锟斤拷锟斤拷锟斤拷玫锟斤拷锟斤拷锟侥伙拷系锟斤拷锟斤拷x锟斤拷锟斤拷值

		// padding + normalizedCoord * (getWidth() - 2 * padding)
		// 锟矫碉拷锟斤拷锟斤拷幕锟较的撅拷锟斤拷x锟斤拷锟斤拷值

		return (float) (padding + normalizedCoord * (getWidth() - 2 * padding));
		// return (float) (normalizedCoord * getWidth());
	}

	/**
	 * Converts screen space x-coordinates into normalized values.
	 * 
	 * @param screenCoord
	 *            The x-coordinate in screen space to convert.
	 * @return The normalized value.
	 */
	private double screenToNormalized(float screenCoord) {
		int width = getWidth();
		if (width <= 2 * padding) {
			// prevent division by zero, simply return 0.
			return 0d;
		} else {
			double result = (screenCoord - padding) / (width - 2 * padding);
			return Math.min(1d, Math.max(0d, result));// 锟斤拷证锟矫革拷值为0-1之锟戒，锟斤拷锟斤拷什么时锟斤拷锟斤拷锟斤拷卸锟斤拷锟斤拷锟斤拷兀锟�
		}
	}

	/**
	 * Callback listener interface to notify about changed range values.
	 * 
	 * @author Stephan Tittel (stephan.tittel@kom.tu-darmstadt.de)
	 * 
	 * @param <T>
	 *            The Number type the RangeSeekBar has been declared with.
	 */
	public interface OnRangeSeekBarChangeListener<T> {
		public void onRangeSeekBarValuesChanged(RangeSeekBar<?> bar, T minValue, T maxValue);
	}

	/**
	 * Thumb constants (min and max).
	 * 只锟斤拷锟斤拷锟斤拷值锟斤拷一锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷锟较碉拷锟斤拷锟街碉拷锟揭伙拷锟斤拷锟斤拷锟斤拷锟斤拷锟斤拷系锟斤拷锟叫≈�
	 */
	private static enum Thumb {
		MIN, MAX
	};

	/**
	 * Utility enumaration used to convert between Numbers and doubles.
	 * 
	 * @author Stephan Tittel (stephan.tittel@kom.tu-darmstadt.de)
	 * 
	 */
	private static enum NumberType {
		LONG, DOUBLE, INTEGER, FLOAT, SHORT, BYTE, BIG_DECIMAL;

		public static <E extends Number> NumberType fromNumber(E value) throws IllegalArgumentException {
			if (value instanceof Long) {
				return LONG;
			}
			if (value instanceof Double) {
				return DOUBLE;
			}
			if (value instanceof Integer) {
				return INTEGER;
			}
			if (value instanceof Float) {
				return FLOAT;
			}
			if (value instanceof Short) {
				return SHORT;
			}
			if (value instanceof Byte) {
				return BYTE;
			}
			if (value instanceof BigDecimal) {
				return BIG_DECIMAL;
			}
			throw new IllegalArgumentException("Number class '" + value.getClass().getName() + "' is not supported");
		}

		public Number toNumber(double value) {
			// this锟斤拷锟斤拷锟斤拷酶梅锟斤拷锟斤拷亩锟斤拷螅�硷拷枚锟斤拷锟斤拷锟叫碉拷枚锟斤拷锟斤拷锟斤拷之一
			switch (this) {
			case LONG:
				return new Long((long) value);
			case DOUBLE:
				return value;
			case INTEGER:
				return new Integer((int) value);
			case FLOAT:
				return new Float(value);
			case SHORT:
				return new Short((short) value);
			case BYTE:
				return new Byte((byte) value);
			case BIG_DECIMAL:
				return new BigDecimal(value);
			}
			throw new InstantiationError("can't convert " + this + " to a Number object");
		}
	}
}