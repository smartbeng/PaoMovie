package com.pdy.information;

import com.pdy.textview.view.MyRelativeLayout;
import com.seu.magicfilter.filter.helper.MagicFilterType;

import android.widget.TextView;

public class VideoInfo {
	public int startVideoTime=0;
	public int endVideoTime=0;
	public MyRelativeLayout videoText=null;
	public String videoPath="";
	public int videoFilter=0;
	public int width = 0;
	public int height = 0;
	public int videoTime = 0;
}
