package com.pdy.common;

public interface InputWindowListener {
    void show();

    void hidden();
}