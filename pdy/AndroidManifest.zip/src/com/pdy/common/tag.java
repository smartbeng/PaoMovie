package com.pdy.common;

public class tag {
	public static String webview = "webview";
}
