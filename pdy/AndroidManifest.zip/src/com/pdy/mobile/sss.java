package com.pdy.mobile;

import java.util.ArrayList;

import com.pdy.camera.HoDragVideo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class sss extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		ArrayList<String> videoPaths = new ArrayList<String>();
		videoPaths.add("/storage/emulated/0/Download/test3.mp4");
		videoPaths.add("/storage/emulated/0/Pictures/pdy/VID_20161220_183447.mp4");
		Intent i = new Intent(this, HoDragVideo.class);
		i.putStringArrayListExtra("videos", videoPaths);
		startActivity(i);
	}
}
