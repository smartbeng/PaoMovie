package com.pdy.mobile;

public class Constants {

	public static String urlHost = "http://paody.lansum.cn/";
	//public static String urlHost = "http://192.168.1.4/";
	public static String urlLogIn="login.html";
	public static String urlIndex = "index.html";
	public static String urlMovieRank ="MovieRank.html"; 
	
	public static String urlPersonal = "personal.html?navbarstyle=1";
	
	public static String urlWoDe = "my.html";
	
	public static String urlSouSuo = "MovieSearch.html?type=";
	
	public static String urlChuiPaoPao = "blowBubble.html";
	
	public static String urlGuanZhuDianYing = "followMovie.html";
	
	public static String urlGuanZhuRen = "followPerson.html";
	
	/**获取信息id**/
	public static String urlGetPaoPao = "http://paody.lansum.cn/api/api/BubbleCircle/JoinedBubbleCircle";
	
	public static String urlPaoPaoEnd = "http://paody.lansum.cn/MovieHome.html";
	
	public static String urlAbout = "http://paody.lansum.cn/about.html";
	/**修改密码**/
	public static String urlModifyPassword = "http://paody.lansum.cn/register.html?type=3";
	
	public static String urlSubmitFeedBack = "http://paody.lansum.cn/api/api/Home/FeedBack";
}
