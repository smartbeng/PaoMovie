package com.pdy.mobile;

public class tags {
	public static String webview = "webview";
}
