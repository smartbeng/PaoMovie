package com.pdy.mobile;

public interface PostResult {

	void PostCallbackResult(String result);

}
