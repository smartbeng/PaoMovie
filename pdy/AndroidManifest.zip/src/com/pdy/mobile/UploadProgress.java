package com.pdy.mobile;

public interface UploadProgress {
	void UploadCallbackResult(float progress);
}
 