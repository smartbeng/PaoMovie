package com.pdy.camera;

import android.content.Context;
import android.util.AttributeSet;
import android.opengl.GLSurfaceView;

public class MyVideoView extends GLSurfaceView
{


	public MyVideoView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO 自动生成的构造函数存根
	}

	public MyVideoView(Context context) {
		super(context);
		// TODO 自动生成的构造函数存根
	}
}

	
