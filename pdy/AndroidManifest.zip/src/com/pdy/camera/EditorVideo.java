package com.pdy.camera;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.List;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

import com.pdy.mobile.R;
import com.pdy.information.VideoInfo;
import com.pdy.mobile.BaseActivity;
import com.pdy.mobile.StaticMethod;
import com.pdy.others.RangeSeekBar;
import com.pdy.others.RangeSeekBar.OnRangeSeekBarChangeListener;
import com.pdy.textview.view.MyRelativeLayout;
import com.seu.magiccamera.common.adapter.FilterAdapter;
import com.seu.magiccamera.common.utils.Constants;
import com.seu.magiccamera.common.view.FilterLayoutUtils;
import com.seu.magicfilter.display.MagicVideoDisplay;
import com.seu.magicfilter.filter.base.MagicVideoInputFilter;
import com.seu.magicfilter.filter.helper.MagicFilterType;
import com.yixia.weibo.sdk.VCamera;

import android.R.integer;
import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.Animator.AnimatorListener;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.SurfaceTexture;
import android.hardware.Camera.Size;
import android.media.MediaPlayer;
import android.opengl.GLES11Ext;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.GLUtils;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.util.Log;
import android.view.DragEvent;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.View.OnDragListener;
import android.view.View.OnTouchListener;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.FrameLayout.LayoutParams;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class EditorVideo extends BaseActivity implements
		// GLSurfaceView.Renderer, SurfaceTexture.OnFrameAvailableListener,
		com.pdy.textview.view.MyRelativeLayout.MyRelativeTouchCallBack, OnClickListener {
	/** 视频预览 */
	private MyVideoView mVideoView;
	/** 播放进度 **/
	Handler handler;
	Runnable videoProgress;
	private SeekBar videoProgressSeekBar;
	/** 播放按键控件 **/
	private ImageView videoPlayImage;
	/** 进度条开始时间 **/
	private TextView videoTimeStart;
	/** 进度条结束时间 **/
	private TextView videoTimeEnd;
	/** 视频时间 **/
	private int videoTime = 0;
	/** 视频路径 **/
	private String videoPath = "";
	/** 裁减视频菜单图标 **/
	private ImageView cutVideo;
	/** 滤镜视频菜单图标 **/
	private ImageView filterVideo;
	/** 字幕视频菜单图标 **/
	private ImageView subtitleVideo;
	/** 裁减缩略图列表 **/
	private LinearLayout cutVideoImage;
	/** 裁减缩略列表 **/
	private FrameLayout editorCutVideo;
	/** 字幕列表 **/
	private LinearLayout editorSubtitleVideo;
	/** 滤镜列表 **/
	private FrameLayout editorFilterVideo;
	/** 视频下标 **/
	int videoIndex = 0;
	/** 字幕布局 **/
	private com.pdy.textview.view.MyRelativeLayout rela;

	private TextView textView;
	private RelativeLayout recordLayout;
	private MagicVideoDisplay mMagicVideoDisplay;
	private FrameLayout mFilterLayout;

	VideoInfo vInfo = null;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO 自动生成的方法存根
		super.onCreate(savedInstanceState);
		setContentView(R.layout.editor_video);
	

		videoIndex = getIntent().getIntExtra("video", 0);
        vInfo = StaticMethod.videosInfo.get(videoIndex);
		videoPath = vInfo.videoPath;
		videoTime = vInfo.videoTime;
		/** 绑定控件 **/
		mVideoView = (MyVideoView) findViewById(R.id.record_preview);
		// mVideoView.setEGLContextClientVersion(2);
		// mVideoView.setRenderer(this);
		recordLayout = (RelativeLayout) findViewById(R.id.record_layout);

		// if(StaticMethod.textviewData!=null&&StaticMethod.textviewData.size()!=0){
		// rela.setTextViewParams(StaticMethod.textviewData.get(0));
		// }
		cutVideo = (ImageView) findViewById(R.id.cut_video);
		subtitleVideo = (ImageView) findViewById(R.id.subtitle_video);
		filterVideo = (ImageView) findViewById(R.id.filter_video);
		editorCutVideo = (FrameLayout) findViewById(R.id.editor_cut_video);
		editorSubtitleVideo = (LinearLayout) findViewById(R.id.editor_subtitle_video);
		editorFilterVideo = (FrameLayout) findViewById(R.id.layout_filter);

		getVideoImage(videoPath);

		max = videoTime;
		getSeek();
		videoProgressSeekBar = (SeekBar) findViewById(R.id.video_progress);

		final TextView subText = (TextView) findViewById(R.id.sub_text);

		if (StaticMethod.textColor.length > StaticMethod.textType.length) {
			length = StaticMethod.textColor.length;
		} else {
			length = StaticMethod.textType.length;
		}
		playVideo();
		initUI();

		/** 绑定返回事件 **/
		findViewById(R.id.back).setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO 自动生成的方法存根
				exitEditVideo();
			}
		});

		cutVideo.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO 自动生成的方法存根
				editorCutVideo.setVisibility(View.VISIBLE);
				editorFilterVideo.setVisibility(View.GONE);
				editorSubtitleVideo.setVisibility(View.GONE);
				StaticMethod.isTouch = false;
				if (rela.content.equals("")
						|| rela.content.equals(getResources().getString(R.string.editor_video_sub))) {
					subText.setText("");
				}
			}
		});

		subtitleVideo.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO 自动生成的方法存根
				editorCutVideo.setVisibility(View.GONE);
				editorFilterVideo.setVisibility(View.GONE);
				editorSubtitleVideo.setVisibility(View.VISIBLE);
				StaticMethod.isTouch = true;
				if (rela.content == null || rela.content.equals("")) {
					subText.setText(getResources().getString(R.string.editor_video_sub));
				}
			}
		});

		filterVideo.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO 自动生成的方法存根
				editorCutVideo.setVisibility(View.GONE);
				editorFilterVideo.setVisibility(View.VISIBLE);
				editorSubtitleVideo.setVisibility(View.GONE);
				if (rela.content.equals("")
						|| rela.content.equals(getResources().getString(R.string.editor_video_sub))) {
					subText.setText("");
				}
				StaticMethod.isTouch = false;

			}
		});

		initConstants();
		initMagicPreview();
		initFilterLayout();
	}

	protected void exitEditVideo() {

	

		if (min != 0) {
			vInfo.startVideoTime = min;
		} else {
			vInfo.startVideoTime = 0;
		}

		if (max != videoTime) {
			vInfo.endVideoTime = max;
		} else {
			vInfo.endVideoTime = videoTime;
		}
		
		vInfo.videoTime = max - min;
		vInfo.videoFilter = mMagicVideoDisplay.getFilter();

		if (rela != null) {
			vInfo.videoText = rela;
			recordLayout.removeView(rela);
		}
		StaticMethod.isTouch = false;
		Intent i = new Intent(EditorVideo.this, HoDragVideo.class);
		i.putExtra("isEditorVideo", true);
		startActivity(i);
		finish();

	}

	private void initFilterLayout() {

		mFilterLayout = (FrameLayout) findViewById(R.id.layout_filter);
		FilterLayoutUtils mFilterLayoutUtils = new FilterLayoutUtils(this, mMagicVideoDisplay);
		mFilterLayoutUtils.init();
	}

	private void initMagicPreview() {
		GLSurfaceView glSurfaceView = (GLSurfaceView) mVideoView;
		String path = StaticMethod.videosInfo.get(videoIndex).videoPath;
		mMagicVideoDisplay = new MagicVideoDisplay(this, glSurfaceView, path);

		Handler filterHandler = new Handler();
		filterHandler.postDelayed(new Runnable() {

			@Override
			public void run() {

				mMagicVideoDisplay.setFilter(MagicFilterType.INKWELL);
				;
			}
		}, 100);
	}

	private void initConstants() {
		Point outSize = new Point();
		getWindowManager().getDefaultDisplay().getRealSize(outSize);
		Constants.mScreenWidth = outSize.x;
		Constants.mScreenHeight = outSize.y;
	}

	int min = 0;
	int max = 0;
	private RangeSeekBar<Integer> seekBar;

	/** 创建滑动条 **/
	private void getSeek() {
		// create RangeSeekBar as Integer range between 20 and 75
		seekBar = new RangeSeekBar<Integer>(0, Math.min(videoTime, maxSeebarTime * 1000), this);
		// seekBar.setNormalizedMinValue((double)
		// StaticMethod.videosInfo.get(videoIndex).startVideoTime / videoTime);
		// seekBar.setNormalizedMaxValue((double)
		// StaticMethod.videosInfo.get(videoIndex).endVideoTime / videoTime);
		// seekBar.setNotifyWhileDragging(true);
		seekBar.setOnRangeSeekBarChangeListener(new OnRangeSeekBarChangeListener<Integer>() {
			@Override
			public void onRangeSeekBarValuesChanged(RangeSeekBar<?> bar, Integer minValue, Integer maxValue) {
				// handle changed range values
				if (minValue == min) {
					max = maxValue;
					mMagicVideoDisplay.seekTo(startTime * 1000 + max);
				} else if (maxValue == max) {
					min = minValue;
					mMagicVideoDisplay.seekTo(startTime * 1000 + min);
				} else {
					Log.i("js", "未匹配的值：" + minValue + "==" + min + "  " + maxValue + "==" + max);
				}
			}
		});
		editorCutVideo = (FrameLayout) findViewById(R.id.editor_cut_video);
		editorCutVideo.addView(seekBar);
	}

	private List<String> mDatas;
	private int maxSeebarTime = 8;
	protected int startTime;
	protected int endTime;
	// 是否已经画缩略图
	private int[] isDrawThumArr;
	Handler imageHandler = new Handler();
	private int maxLength;
	private int currentTime;
	private VideoInfo currentVideoInfo;
	private HorizontalScrollView videos_horizontal;
	private int thumSize;

	/** 获取视频缩略图 **/
	private void getVideoImage(String path) {

		// 使用handler时首先要创建一个handler

		cutVideoImage = (LinearLayout) findViewById(R.id.cut_video_image);
		videos_horizontal = (HorizontalScrollView) findViewById(R.id.videos_horizontal);
		thumSize = Constants.mScreenWidth / (maxSeebarTime + 1);
		maxLength = StaticMethod.videosInfo.get(videoIndex).endVideoTime / 1000;
		isDrawThumArr = new int[maxLength];

		videos_horizontal.setOnTouchListener(new OnTouchListener() {

			private int mCurrentPosX;
			int mPosX;
			int mPosY;
			private int mCurrentPosY;

			@Override
			public boolean onTouch(View v, MotionEvent event) {

				// TODO Auto-generated method stub
				if (MotionEvent.ACTION_DOWN == event.getAction()) {
					mPosX = (int) event.getX();
					mPosY = (int) event.getY();
				}
				if (MotionEvent.ACTION_MOVE == event.getAction()) {
					mCurrentPosX = (int) event.getX() - mPosX;
					mCurrentPosY = (int) event.getY() - mPosY;

					mPosX = (int) event.getX();
					mPosY = (int) event.getY();

					startTime = (int) (videos_horizontal.getScrollX() / thumSize);
					endTime = startTime + Math.min(maxSeebarTime, maxLength - startTime);
					seekBar.start = startTime * 1000;
					seekBar.invalidate();

					String startStr = getFormatTime(startTime);
					String endStr = getFormatTime(endTime);

					// EditorVideo.this.videoTimeStart.setText(startStr);
					// EditorVideo.this.videoTimeEnd.setText(endStr);

				}
				if (MotionEvent.ACTION_UP == event.getAction()) {
					new Handler().postDelayed(new Runnable() {

						@Override
						public void run() {
							// TODO Auto-generated method stub
							int diff = mMagicVideoDisplay.getCurrentPosition() - startTime * 1000;
							startTime = (int) (videos_horizontal.getScrollX() / thumSize);
							endTime = startTime + Math.min(maxSeebarTime, maxLength - startTime);
							seekBar.start = startTime * 1000;
							seekBar.invalidate();

							mMagicVideoDisplay.seekTo(startTime * 1000 + diff);
							refreshThumImage();

						}
					}, 500);

				}
				if (mCurrentPosX - mPosX > 0 && Math.abs(mCurrentPosY - mPosY) < 10) {

					Log.e("", "向右的按下位置" + mPosX + "移动位置" + mCurrentPosX);

				} else if (mCurrentPosX - mPosX < 0 && Math.abs(mCurrentPosY - mPosY) < 10) {

					Log.e("", "向左的按下位置" + mPosX + "移动位置" + mCurrentPosX);

				} else if (mCurrentPosY - mPosY > 0 && Math.abs(mCurrentPosX - mPosX) < 10)

				{
					Log.e("", "向下的按下位置" + mPosX + "移动位置" + mCurrentPosX);

				} else if (mCurrentPosY - mPosY < 0 && Math.abs(mCurrentPosX - mPosX) < 10)

				{
					Log.e("", "向上的按下位置" + mPosX + "移动位置" + mCurrentPosX);

				}

				return false;

			}

			private String getFormatTime(int startTime) {
				int min = startTime / 60;
				int sec = startTime % 60;
				String minStr = String.format("%02d", min);
				String secStr = String.format("%02d", sec);
				String str = minStr + ":" + secStr;
				return str;
			}
		});

		currentTime = videoTime / maxLength;
		List<ImageView> ivList = new ArrayList<ImageView>();
		for (int i = 0; i < maxLength; i++) {
			final ImageView iv = new ImageView(EditorVideo.this);
			ivList.add(iv);
			iv.setScaleType(ImageView.ScaleType.FIT_XY);

			final android.view.ViewGroup.LayoutParams ps = new android.view.ViewGroup.LayoutParams(thumSize, thumSize);

			iv.setMaxWidth(thumSize);
			iv.setMaxHeight(thumSize);
			iv.setLayoutParams(ps);
			cutVideoImage.addView(iv);
		}
		currentVideoInfo = StaticMethod.videosInfo.get(videoIndex);
		startTime = currentVideoInfo.startVideoTime / 1000;
		videos_horizontal.setScrollX(startTime);
		refreshThumImage();

	}

	private void refreshThumImage() {

		int targetIndex = 0;
		for (int i = 0; i < maxSeebarTime; i++) {

			Log.i("a", "time:" + currentTime * (i + 1));

			final int ii = i + startTime;
			if (ii > maxLength-1) {
				return;
			}

			if (isDrawThumArr[ii] == 1) {
				continue;
			}

			isDrawThumArr[ii] = 1;

			final ImageView iv = (ImageView) cutVideoImage.getChildAt(ii);

			Thread thread = new Thread(new Runnable() {

				@Override
				public void run() {

					if (ii == maxLength - 1) {

						final Bitmap bitmap = StaticMethod.getVideoThumbnailAtTime(videoPath,
								(videoTime - 1000) * 1000);
						runOnUiThread(new Runnable() {
							public void run() {
								iv.setImageBitmap(bitmap);

							}
						});
					} else {
						final Bitmap bitmap = StaticMethod.getVideoThumbnailAtTime(videoPath,
								currentTime * (ii + 1) * 1000);
						runOnUiThread(new Runnable() {
							public void run() {
								iv.setImageBitmap(bitmap);

							}
						});
					}
					// TODO 自动生成的方法存根

				}
			});
			targetIndex++;
			imageHandler.postDelayed(thread, targetIndex * 300);

		}
	}

	private void playVideo() {
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				// TODO 自动生成的方法存根

				videoPlayImage = (ImageView) findViewById(R.id.video_play_image);
				videoTimeStart = (TextView) findViewById(R.id.video_time_start);
				videoTimeEnd = (TextView) findViewById(R.id.video_time_end);
				videoTimeEnd.setText(StaticMethod.secToTime(StaticMethod.videosInfo.get(videoIndex).endVideoTime + ""));
				/** 播放按钮监听 **/
				videoPlayImage.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View arg0) {
						if (mMagicVideoDisplay.isPlaying()) {
							videoPlayImage.setImageResource(R.drawable.video_play);
							handler.removeCallbacks(videoProgress);
							mMagicVideoDisplay.pause();
						} else {
							if (videoProgressSeekBar.getProgress() < 99) {
								videoPlayImage.setImageResource(R.drawable.video_pause);
								handler.post(videoProgress);
								mMagicVideoDisplay.start();
							}
						}
					}
				});

				videoProgressSeekBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

					@Override
					public void onStopTrackingTouch(SeekBar arg0) {
						// TODO Auto-generated method stub
						int ti = arg0.getProgress() * videoTime / 100;
						mMagicVideoDisplay.seekTo(ti);
						
						startTime = ti/1000;
						videos_horizontal.setScrollX(startTime * thumSize);
						seekBar.start=startTime;
						seekBar.invalidate();
						refreshThumImage();
							
						
						videoTimeStart.setText(StaticMethod.secToTime(ti + ""));
						handler.post(videoProgress);
						videoPlayImage.setImageResource(R.drawable.video_pause);
						mMagicVideoDisplay.start();
					}

					@Override
					public void onStartTrackingTouch(SeekBar arg0) {
						// TODO Auto-generated method stub

						handler.removeCallbacks(videoProgress);
					}

					@Override
					public void onProgressChanged(SeekBar arg0, int arg1, boolean arg2) {
						// TODO Auto-generated method stub

					}
				});

				// 使用handler时首先要创建一个handler
				handler = new Handler();
				// 要用handler来处理多线程可以使用runnable接口，这里先定义该接口
				// 线程中运行该接口的run函数
				videoProgress = new Runnable() {
					public void run() {
						if (mMagicVideoDisplay.isPlaying()) {
							int time = 0;
							time = mMagicVideoDisplay.getCurrentPosition();
							if (time >= (startTime * 1000 + max - 100)) {
								handler.removeCallbacks(videoProgress);
								mMagicVideoDisplay.seekTo(startTime * 1000 + min);
								videoPlayImage.setImageResource(R.drawable.video_play);
								mMagicVideoDisplay.pause();
								videos_horizontal.setScrollX(startTime * thumSize);
								refreshThumImage();
							}
							int progress = 0;
							progress = time * 100 / videoTime;
							videoProgressSeekBar.setProgress(progress);
							videoTimeStart.setText(StaticMethod.secToTime(time + ""));
						}
						// 延时0.1s后又将线程加入到线程队列中
						handler.postDelayed(videoProgress, 100);
					}
				};
				handler.post(videoProgress);
			}
		});

	}

	@Override
	protected void onPause() {
		super.onPause();
		if (mMagicVideoDisplay != null)
			mMagicVideoDisplay.onPause();
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (mMagicVideoDisplay != null)
			mMagicVideoDisplay.onResume();
	}

	@Override
	protected void onDestroy() {

		// TODO Auto-generated method stub
		super.onDestroy();
		if (mMagicVideoDisplay != null)
			mMagicVideoDisplay.onDestroy();
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		if (keyCode == KeyEvent.KEYCODE_BACK) {
			exitEditVideo();
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	public void initUI() {
		VideoInfo vInfo = StaticMethod.videosInfo.get(videoIndex);
		rela = (MyRelativeLayout) findViewById(R.id.id_rela);
		if (vInfo.videoText != null) {
			recordLayout.removeView(rela);
			recordLayout.addView(vInfo.videoText);
			rela = (MyRelativeLayout) vInfo.videoText;
			rela.textView = (TextView) vInfo.videoText.findViewById(R.id.sub_text);
		} else {

			rela.textView = (TextView) findViewById(R.id.sub_text);
		}
		rela.setMyRelativeTouchCallBack(this);

		LinearLayout color = (LinearLayout) findViewById(R.id.editor_subtitle_video_color);
		LinearLayout type = (LinearLayout) findViewById(R.id.editor_subtitle_video_type);
		for (int i = 0; i < StaticMethod.textColor.length; i++) {
			View subItem = LayoutInflater.from(this).inflate(R.layout.sub_item, null);
			ImageView item = (ImageView) subItem.findViewById(R.id.color);
			item.setTag("color" + i);
			item.setOnClickListener(this);
			item.setBackgroundColor(getResources().getColor(StaticMethod.textColor[i]));
			color.addView(subItem);
		}

		for (int i = 0; i < StaticMethod.textType.length; i++) {
			View subItem = LayoutInflater.from(this).inflate(R.layout.sub_item, null);
			TextView item = (TextView) subItem.findViewById(R.id.text);
			item.setTag("type" + i);
			item.setOnClickListener(this);
			item.setText(StaticMethod.textType[i]);
			type.addView(subItem);
		}

	}

	@Override
	public void touchMoveCallBack(int direction) {
		// TODO 自动生成的方法存根

	}

	@Override
	public void onTextViewMoving(TextView textView) {
		// TODO 自动生成的方法存根

	}

	@Override
	public void onTextViewMovingDone() {
		// TODO 自动生成的方法存根

	}

	int length = 0;

	@Override
	public void onClick(View v) {
		if (rela.textView != null) {
			String tag = v.getTag().toString();
			// TODO 自动生成的方法存根
			for (int i = 0; i < length; i++) {
				if (tag.equals("color" + i)) {
					rela.color = StaticMethod.textColor[i];
					rela.addTextView(rela.textView, rela.textView.getX(), rela.textView.getY(),
							rela.content, StaticMethod.textColor[i], rela.textView.getTextSize(),
							rela.textView.getRotation(), rela.typeface);
					return;
				} else if (tag.equals("type" + i)) {
					rela.typeface = StaticMethod.typefaces[i];
					rela.addTextView(rela.textView, rela.textView.getX(), rela.textView.getY(),
							rela.content, rela.color, rela.textView.getTextSize(),
							rela.textView.getRotation(), rela.typeface);
					return;
				}
			}
		}
	}

	class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.MyViewHolder> {

		@Override
		public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			MyViewHolder holder = new MyViewHolder(
					LayoutInflater.from(EditorVideo.this).inflate(R.layout.item_home, parent, false));
			return holder;
		}

		@Override
		public void onBindViewHolder(MyViewHolder holder, int position) {
			holder.tv.setText(mDatas.get(position));
		}

		@Override
		public int getItemCount() {
			return mDatas.size();
		}

		class MyViewHolder extends ViewHolder {

			TextView tv;

			public MyViewHolder(View view) {
				super(view);
				tv = (TextView) view.findViewById(R.id.id_num);
			}
		}
	}

}