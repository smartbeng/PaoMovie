package com.pdy.webview;

import java.io.File;

import com.pdy.mobile.BaseActivity;
import com.pdy.mobile.R;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.RelativeLayout;
import in.srain.cube.views.ptr.PtrClassicFrameLayout;

public class MyWebChromeClient extends WebChromeClient {

	public static final int FILECHOOSER_RESULTCODE =1212;
	private String mCameraFilePath;
	private ValueCallback<Uri> mUploadMessage;
	BaseActivity act;
	WebViewScrollChanged webview;
	
	public MyWebChromeClient(BaseActivity act) {
		
		this.act=act;
		
	}
	
	
	RelativeLayout webviews;
	  // 一个回调接口使用的主机应用程序通知当前页面的自定义视图已被撤职  
    CustomViewCallback customViewCallback;  
    // 进入全屏的时候  
    @Override  
    public void onShowCustomView(View view, CustomViewCallback callback) {  
    	webviews = (RelativeLayout) act.findViewById(R.id.webviews);
    	int child = webviews.getChildCount();
    	RelativeLayout a = (RelativeLayout) webviews.getChildAt(child-1);
    	PtrClassicFrameLayout b = (PtrClassicFrameLayout) a.getChildAt(0);
    	webview = (WebViewScrollChanged) b.getChildAt(0);
    	//webview = (WebViewScrollChanged) a.getChildAt(child-1);
    	//webview=(WebViewScrollChanged)act.findViewById(R.id.webView);
        // 赋值给callback  
        customViewCallback = callback;  
        // 设置webView隐藏  
		act.isFull = true;
		// 声明video，把之后的视频放到这里面去
		FrameLayout video = (FrameLayout) act.findViewById(R.id.video_view);

		// 将video放到当前视图中
		video.addView(view);

		video.setVisibility(View.VISIBLE);
		
		// 设置webView隐藏
		//webview.setVisibility(View.GONE);
		
		// 横屏显示
		act.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
		// 设置全屏
		setFullScreen();
		
	
	}

	// 退出全屏的时候
	@Override
	public void onHideCustomView() {
		if (customViewCallback != null) {
			// 隐藏掉
			customViewCallback.onCustomViewHidden();
		}
		// 用户当前的首选方向
		act.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_USER);
		act.isFull = false;
		// 设置WebView可见
		webview.setVisibility(View.VISIBLE);
		
		FrameLayout video = (FrameLayout) act.findViewById(R.id.video_view);
		video.setVisibility(View.GONE);
		// 退出全屏
		quitFullScreen();

	}

    /** 
     * 设置全屏 
     */  
    private void setFullScreen() {  
        // 设置全屏的相关属性，获取当前的屏幕状态，然后设置全屏  
       act. getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,  
                WindowManager.LayoutParams.FLAG_FULLSCREEN);  
        // 全屏下的状态码：1098974464  
        // 窗口下的状态吗：1098973440  
    }  
  
    /** 
     * 退出全屏 
     */  
    private void quitFullScreen() {  
        // 声明当前屏幕状态的参数并获取  
        final WindowManager.LayoutParams attrs = act.getWindow().getAttributes();  
        attrs.flags &= (~WindowManager.LayoutParams.FLAG_FULLSCREEN);  
        act.getWindow().setAttributes(attrs);  
        act.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);  
    }  
    
    @Override  
    public void onProgressChanged(WebView view, int newProgress) {  
        super.onProgressChanged(view, newProgress);  
    }  
	
	// For Android 3.0+
	public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType) {
		myopenFileChooser(uploadMsg, acceptType, null);
	}

	// For Android < 3.0
	public void openFileChooser(ValueCallback<Uri> uploadMsg) {
		myopenFileChooser(uploadMsg, "", null);
	}

	// For Android > 4.1.1
	public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture) {
		myopenFileChooser(uploadMsg, acceptType, capture);
	}

	public void myopenFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture) {
		mUploadMessage = uploadMsg;

		act.startActivityForResult(Intent.createChooser(createDefaultOpenableIntent(acceptType, capture), "完成操作需要使用"),
				FILECHOOSER_RESULTCODE);

	}
   
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == FILECHOOSER_RESULTCODE) {
			// if (null == mUploadMessage) return;
			Uri result = data == null || resultCode != act.RESULT_OK ? null : data.getData();
			if (result == null && data == null && resultCode == Activity.RESULT_OK) {
				File cameraFile = new File(mCameraFilePath);
				if (cameraFile.exists()) {
					result = Uri.fromFile(cameraFile);
					// Broadcast to the media scanner that we have a new photo
					// so it will be added into the gallery for the user.
					act.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, result));
				}
			}
			mUploadMessage.onReceiveValue(result);
			mUploadMessage = null;

		}
		
	}

	private Intent createDefaultOpenableIntent(String acceptType, String capture) {
		// Create and return a chooser with the default OPENABLE
		// actions including the camera, camcorder and sound
		// recorder where available.
		Intent i = new Intent(Intent.ACTION_GET_CONTENT);
		i.addCategory(Intent.CATEGORY_OPENABLE);
		if (acceptType == null || acceptType.equals("")) {
			acceptType = "*/*";
		}
		i.setType(acceptType);
		//
		// List<Intent> list=new ArrayList<Intent>();
		// list.add(createCameraIntent());
		//
		// list.add(createCamcorderIntent());

		Intent chooser = null;
		if (acceptType.matches("video.+")) {
			chooser = createChooserIntent(

					createCamcorderIntent()
			// createSoundRecorderIntent()
			);

		} else if (acceptType.matches("image.+")) {
			chooser = createChooserIntent(

					createCameraIntent()
			// createSoundRecorderIntent()
			);

		} else {
			chooser = createChooserIntent();
		}

		chooser.putExtra(Intent.EXTRA_INTENT, i);
		return chooser;
	}

	private Intent createChooserIntent(Intent... list) {
		Intent chooser = new Intent(Intent.ACTION_CHOOSER);
		chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, list);
		chooser.putExtra(Intent.EXTRA_TITLE, "File Chooser");
		return chooser;
	}

	private Intent createCameraIntent() {
		Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
		File externalDataDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
		File cameraDataDir = new File(externalDataDir.getAbsolutePath() + File.separator + "browser-photos");
		cameraDataDir.mkdirs();
		mCameraFilePath = cameraDataDir.getAbsolutePath() + File.separator + System.currentTimeMillis() + ".jpg";
		cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(mCameraFilePath)));
		return cameraIntent;
	}

private Intent createCamcorderIntent() {
		Intent cameraIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
		File externalDataDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
		File cameraDataDir = new File(externalDataDir.getAbsolutePath() + File.separator + "browser-movies");
		cameraDataDir.mkdirs();
		mCameraFilePath = cameraDataDir.getAbsolutePath() + File.separator + System.currentTimeMillis() + ".mp4";
		cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(new File(mCameraFilePath)));
		return cameraIntent;

	}

private Intent createSoundRecorderIntent() {
     return new Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION);
    }
	
}
