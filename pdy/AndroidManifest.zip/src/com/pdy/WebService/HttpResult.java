package com.pdy.WebService;

public class HttpResult {
	public String result="";
	public String cookie;
}
